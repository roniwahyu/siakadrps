@extends('layouts.info')
@section('content')
<div class="container my-4">
	<h4>Features</h4>
	<hr />
	<div>
		<p>Put page content here.</p>
	</div>
</div>
@endsection