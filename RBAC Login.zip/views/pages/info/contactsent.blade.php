@extends('layouts.info')
@section('content')
<div class="container my-4">
	<div style="margin:40px 0;">
		<div class="animated bounce">
			<h4 class="bold text-success">Thank You For Contacting Us ...</h4>
			<hr />
			<p class="text-muted">We Will Get Back to You Soon.</p>
		</div>
	</div>
</div>
@endsection